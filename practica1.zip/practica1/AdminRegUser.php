<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="AdminRegUser.css">
    <title>Registro</title>
</head>
<header class="title">
    <h1>Pizzeria Il Forno di Napoli</h1>
</header>
<nav>
    <ul id="barra">
        <li class="barraa"><a class="linkNav" href="IndexAdmin.php">Inicio</a>
        </li>
        <li class="barraa"><a class="linkNav" href="AdminMenu.php">Menu</a>
        </li>
        <li class="barraa"><a class="linkNav" href="AdminUbicacion.html">Ubicacion y contactos</a>
        </li>
        <li class="barraa"><a class="linkNav" href="AdminUsuarios.php">Usuarios</a>
        </li>
        <li class="barraa"><a class="linkNav" href="Home.php">Log out</a>
        </li>
    </ul>
</nav>
<body>
    <section class="genCont">
        <form method="post" action="Registro.php">
        <div class="form">
            <?php
                if(empty($_GET['repeatemail'])){
                    $email = "";
                }
                else{
                    $email = "(Email ya registrado)";
                }
                if(empty($_GET['repeatuser'])){
                    $user = "";
                }
                else{
                    $user = "(usuario ya registrado)";
                }
                if(empty($_GET['repeatphone'])){
                    $phone = "";
                }
                else{
                    $phone = "(telefono ya registrado)";
                }
            ?>
            <label>Correo <?php echo $email?></label>
            <input type="email" id="email" name="email">
            <label>Nombre completo</label>
            <input type="text" id="name" name="name">
            <label>Usuario <?php echo $user?></label>
            <input type="text" id="user" name="user">
            <label>Password</label>
            <input type="password" id="pass" name="pass">
            <label>Telefono <?php echo $phone?></label>
            <input type="number" id="phone" name="phone" min="1000000000" max="9999999999">
            <input type="hidden" id="permit" name="permit" value="admin">
            <div>
                <button type="submit" name="Registrar" class="button">Registrar</button>
            </div> 
        </form>
        </div>
    </section>
</body>
<footer>
    <div class="container">
        <div class="social-icons">
            <a href="https://www.instagram.com" target="_blank"> <img src="Imagenes/instagram.png" alt=""><i>Il Forno di Napoli</i></a>
            <a href="https://www.facebook.com" target="_blank"><img src="Imagenes/facebook.png" alt=""><i>Forno_di_Napoli</i></a>
        </div>
        <p>© 2023 Pizzería Il Forno di Napoli</p>
    </div>
</footer>
</html>