<?php
    session_start();
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\SMTP;
    use PHPMailer\PHPMailer\Exception;
    include 'Connection.php';
    require 'vendor/autoload.php';
    require 'vendor/fpdf/fpdf.php';

    $total = $_POST['total'];
    $user_id = $_SESSION['user_id'];

    $sql = "SELECT name, price, amount FROM carrito WHERE idusuario = '$user_id'";
	$result = $con->query($sql);

    $pdf = new FPDF();

    $pdf -> AddPage();
    
    $pdf -> SetFont('Arial', 'B', 24);

    $pdf -> Cell(30,10,'Factura',1,0,'C');

    $pdf -> Image('Imagenes/PizzaMarg.jpeg',10,8,33);
    
    $pdf -> Cell(80);
    
    $pdf -> Ln(20);
    
    $pdf->Cell(60,20, "Gracias por tu compra"." ".$_SESSION["user_user"]);

    $pdf -> SetFont('Arial', 'B', 12);

    while($rows=$result->fetch_assoc()) {
        $pdf->Ln(20);
        $pdf->Cell(60,20, "Concepto: X ".$rows['amount']." ".$rows['name'].  " \$".$rows['price']." c/u");
    }

    $pdf->Ln(20);
    $pdf->Cell(60,20, "Total: ".$total." \$");

    $pdf->Output("Compra.pdf","F");

    $outlook_mail = new PHPMailer();
    $outlook_mail->IsSMTP();
    $outlook_mail->Host = 'smtp-mail.outlook.com';
    $outlook_mail->Port = 587;
    $outlook_mail->SMTPSecure = 'tls';
    $outlook_mail->SMTPDebug = 0;
    $outlook_mail->SMTPAuth = true;
    $outlook_mail->Username = 'IlFornoDiNapoli@outlook.com';
    $outlook_mail->Password = 'cortineando123';
     
    $outlook_mail->From = 'IlFornoDiNapoli@outlook.com';
    $outlook_mail->FromName = 'IlfornoDiNapoli.com';
    $outlook_mail->AddAddress($_SESSION['user_email'], $_SESSION['user_user']);  
     
    $outlook_mail->IsHTML(true);
     
    $outlook_mail->Subject = 'Recibo de compra';
    $outlook_mail->Body    = 'HTML_CONTENT';
    $outlook_mail->AltBody = 'This is the body in plain text for non-HTML mail clients at https://onlinecode.org/';
    $outlook_mail->AddAttachment('Compra.pdf', '', $encoding = 'base64', $type = 'application/pdf');
     
    if(!$outlook_mail->Send()) {
        echo 'Message could not be sent.';
        echo 'Mailer Error: ' . $outlook_mail->ErrorInfo;
    }
    else {
        echo 'Message of Send email using Outlook SMTP server has been sent';
        header("location: Home.php");
    }

?>
