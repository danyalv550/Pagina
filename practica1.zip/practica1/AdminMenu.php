<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="AdminMenu.css">
    <title>Menu</title>
</head>
<header class="title">
    <h1>Pizzeria Il Forno di Napoli</h1>
</header>
<nav>
    <ul id="barra">
        <li class="barraa"><a class="linkNav" href="IndexAdmin.php">Inicio</a>
        </li>
        <li class="barraa"><a class="linkNav" href="AdminMenu.php">Menu</a>
        </li>
        <li class="barraa"><a class="linkNav" href="AdminUbicacion.html">Ubicacion y contactos</a>
        </li>
        <li class="barraa"><a class="linkNav" href="AdminUsuarios.php">Usuarios</a>
        </li>
        <li class="barraa"><a class="linkNav" href="Home.php">Log out</a>
        </li>
    </ul>
</nav>
<body>
<div class="searchbar">
        <div class="search">
            <form action="AdminMenu.php" method="Get">
            <?php 
            include 'Connection.php';
            @$search=$_GET['search'];
            ?>
            <input type="text" id="search" name="search" value="<?php echo $search?>">
            <button type="submit" name="Buscar" class="button">Buscar</button>
            <?php
            if(is_null($search)) {
                $sqlPizza = mysqli_query($con, "SELECT * FROM pizzas");
                $sqlPasta = mysqli_query($con, "SELECT * FROM pastas");
                $sqlPostres = mysqli_query($con, "SELECT * FROM postres");
                $con->close();
            }
            else {
                $sql = "SELECT * FROM pizzas WHERE name LIKE '%$search%' OR price LIKE '%$search%' OR description LIKE '%$search%'; SELECT * FROM pastas WHERE name LIKE '%$search%' OR price LIKE '%$search%' OR description LIKE '%$search%' SELECT * FROM postres WHERE name LIKE '%$search%' OR price LIKE '%$search%' OR description LIKE '%$search%' ";
                $sqlPizza = mysqli_query($con, "SELECT * FROM pizzas WHERE name LIKE '%$search%' OR price LIKE '%$search%' OR description LIKE '%$search%'");
                $sqlPasta = mysqli_query($con, "SELECT * FROM pastas WHERE name LIKE '%$search%' OR price LIKE '%$search%' OR description LIKE '%$search%'");
                $sqlPostres = mysqli_query($con, "SELECT * FROM postres WHERE name LIKE '%$search%' OR price LIKE '%$search%' OR description LIKE '%$search%'");
                $con->close();
            } ?>
            </form>
        </div>
    </div>
    <section class="menu">
        <h2>Pizzas</h2>
        <ul>
            <li class="item" onclick="window.location.href='AdminRegProd.php?item=Pizza'">
                <div class="imageCont">
                    <img src="Imagenes/PizzaMarg.jpeg" alt="" class="image">
                </div>
                <div class="textCont">
                    <h3>Agregar item</h3>
                    <p>Descripcion.</p>
                    <span class="price">Precio</span>
                </div>
            </li>
            <?php
                include 'Connection.php';
                while($row = mysqli_fetch_array($sqlPizza)){
                    ?>
                        <li class="item" onclick="window.location.href='AdminModProd.php?id=<?php echo $row['id'];?>&item=Pizzas'">
                            <div class="imageCont">
                                <img src="Imagenes/<?php echo $row['image'];?>" alt="" class="image">
                            </div>
                            <div class="textCont">
                                <h3><?php echo $row['name'];?></h3>
                                <p><?php echo $row['description'];?></p>
                                <span class="price">$<?php echo $row['price'];?></span>
                            </div>
                        </li>
                    <?php
                }
            ?>
        </ul>
        <h2>Pastas</h2>
        <ul>
            <li class="item" onclick="window.location.href='AdminRegProd.php?item=Pasta'">
                <div class="imageCont">
                    <img src="Imagenes/SpaguetiBol.jpg" alt="" class="image">
                </div>
                <div class="textCont">
                    <h3>Agregar item</h3>
                    <p>Descripcion.</p>
                    <span class="price">Precio</span>
                </div>
            </li>
            <?php
                include 'Connection.php';
                while($row = mysqli_fetch_array($sqlPasta)){
                    ?>
                        <li class="item" onclick="window.location.href='AdminModProd.php?id=<?php echo $row['id'];?>+?item=Pastas'">
                            <div class="imageCont">
                                <img src="Imagenes/<?php echo $row['image']?>" alt="" class="image">
                            </div>
                            <div class="textCont">
                                <h3><?php echo $row['name']?></h3>
                                <p><?php echo $row['description']?></p>
                                <span class="price">$<?php echo $row['price']?></span>
                            </div>
                        </li>
                    <?php
                }
            ?>
        </ul>
        <h2>Postres</h2>
        <ul>
            <li class="item" onclick="window.location.href='AdminRegProd.php?item=Postre'">
                <div class="imageCont">
                    <img src="Imagenes/Tiramisu.jpeg" alt="" class="image">
                </div>
                <div class="textCont">
                    <h3>Agregar item</h3>
                    <p>Descripcion.</p>
                    <span class="price">Precio</span>
                </div>
            </li>
            <?php
                include 'Connection.php';
                while($row = mysqli_fetch_array($sqlPostres)){
                    ?>
                        <li class="item" onclick="window.location.href='AdminModProd.php?id=<?php echo $row['id']?>+?item=Postres'">
                            <div class="imageCont">
                                <img src="Imagenes/<?php echo $row['image']?>" alt="" class="image">
                            </div>
                            <div class="textCont">
                                <h3><?php echo $row['name']?></h3>
                                <p><?php echo $row['description']?></p>
                                <span class="price">$<?php echo $row['price']?></span>
                            </div>
                        </li>
                    <?php
                }
            ?>
        </ul>
    </section>
</body>
<footer>
    <div class="container">
        <div class="social-icons">
            <a href="https://www.instagram.com" target="_blank"> <img src="Imagenes/instagram.png" alt=""><i>Il Forno di Napoli</i></a>
            <a href="https://www.facebook.com" target="_blank"><img src="Imagenes/facebook.png" alt=""><i>Forno_di_Napoli</i></a>
        </div>
        <p>© 2023 Pizzería Il Forno di Napoli</p>
    </div>
</footer>
</html>