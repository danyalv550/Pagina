<?php
include 'Connection.php';

$item = $_POST['item'];
$name = $_POST['name'];
$image= $_POST['image'];
$description = $_POST['description'];
$price = $_POST['price'];

$Sql = mysqli_query($con,"INSERT INTO $item (id,name,image,description,price) values (0,'$name','$image','$description','$price')");
if($Sql){
    header("location: AdminMenu.php");
}
else{
    echo "Usuario no agregado";
}
?>