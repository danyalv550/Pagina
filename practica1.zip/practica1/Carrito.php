<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Carrito.css">
    <title>Pizzeria</title>
</head>
<header class="title">
    <h1>Pizzeria Il Forno di Napoli</h1>
</header>
<nav>
    <ul id="barra">
        <?php
            if(empty($_SESSION['user_id'])){
                $link = "LoginPage.php";
                $text = "Log in";
            }
            else{
                $link = "LogOut.php";
                $username = $_SESSION['user_user'];
                $text = "Log out ($username)";
            }
        ?>
        <li class="barraa"><a class="linkNav" href="Home.php">Inicio</a>
        </li>
        <li class="barraa"><a class="linkNav" href="Menu.php">Menu</a>
        </li>
        <li class="barraa"><a class="linkNav" href="Ubicacion.php">Ubicacion y contactos</a>
        </li>
        <li class="barraa"><a class="linkNav" href=<?php echo $link ?>><?php echo $text?></a>
        </li>
        <?php if(empty($_SESSION['user_id'])){
            ?><li class="barraa"><a class="linkNav" href="RegistroPage.php">Registrarse</a>
            </li><?php
        }
        ?>
        <?php if(isset($_SESSION['user_id'])){
            ?><li class="barraa"><a class="linkNav" href="Carrito.php">Carrito</a><?php
        }
        ?>
        </li>
    </ul>
</nav>
<body>
    <h2 class="Slogan">
        Carrito
    </h2>
    <div class="general">
        <table>
            <?php
                include 'Connection.php';
                $idusuario = $_SESSION['user_id'];
                $sql = mysqli_query($con, "SELECT * FROM carrito WHERE idusuario='$idusuario'")
            ?>
        <thead>
            <tr>
                <th>Producto</th><th>Nombre</th><th>Descripcion</th><th>Precio p/u</th><th>Cantidad</th><th>Modificar</th>
            </tr>
        </thead>
        <?php 
            include 'Connection.php';
            $count = 0;
            while($row = mysqli_fetch_array($sql))
            {
            ?> 
            <tr>
                <td><div class="imagen"><img src="Imagenes/<?php echo $row['image'] ?>"></img></div></td>
                <td><?php echo $row['name'] ?></td>
                <td><?php echo $row['description'] ?></td>
                <td>$<?php echo $row['price'] ?></td>
                <form method="POST" action="ModCarrito.php">
                <td><div><input class="amount" type="number" id="amount" name="amount" min="0" value="<?php echo $row['amount'] ?>"></div></td>
                <td>
                    <input type="hidden" id="id" name="id" value="<?php echo $row['id']?>">
                    <div class="botones">
                    <button type="submit" name="Modificar" class="button">Modificar</button>
                </form>
                    <form method="POST" action="DelCarrito.php">
                        <button type="submit" name="Eliminar" class="button">Eliminar</button>
                        <input type="hidden" id="id" name="id" value="<?php echo $row['id'] ?>">
                    </form>
                    </div>
                </td>
            </tr>
            <?php
                $count++;
                $subtotal = $row['price'] * $row['amount'];
                @$total = $total + $subtotal;
            }
            if($count > 0){
                ?>
                <tr>
                <td></td>
                <td></td>
                <td></td>
                <td>$<?php echo $total;?></td>
                <td></td>
                <td>
                    <div class="botones">
                    <form method="POST" action="Compra.php">
                        <button type="submit" name="Confirmar" class="button">Confirmar Compra</button>
                        <input type="hidden" id="total" name="total" value="<?php echo $total?>">
                    </form>
                    </div>
                </td>
            </tr>
            <?php
            }
            ?>    
        </table>
    </div>   
</body>
<footer>
    <div class="container">
        <div class="social-icons">
            <a href="https://www.instagram.com" target="_blank"> <img src="Imagenes/instagram.png" alt=""><i>Il Forno di Napoli</i></a>
            <a href="https://www.facebook.com" target="_blank"><img src="Imagenes/facebook.png" alt=""><i>Forno_di_Napoli</i></a>
        </div>
        <p>© 2023 Pizzería Il Forno di Napoli</p>
      </div>
</footer>
</html>