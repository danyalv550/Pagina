<?php
include 'Connection.php';

$id = $_POST['id'];
$name = $_POST['name'];
$image = $_POST['image'];
$description = $_POST['description'];
$price = $_POST['price'];
$item = $_POST['item'];

$update = "UPDATE $item SET name='$name', image='$image', description='$description', price='$price' WHERE id='$id'";
if ($con->query($update) === TRUE){
    header("location: AdminMenu.php");
}
    else{
        echo "Usuario no agregado";
    }
?>