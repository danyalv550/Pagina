<?php
include 'Connection.php';

$id = $_POST['id'];
$amount = $_POST['amount'];

$modify = "UPDATE carrito SET amount = '$amount' WHERE id = '$id'";
if ($con->query($modify) === TRUE){
    header("location: Carrito.php");
}
else{
    echo "No se pudo modificar";
}
?>