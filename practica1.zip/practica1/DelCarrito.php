<?php
include 'Connection.php';

$id = $_POST['id'];
$delete = "DELETE FROM carrito WHERE id='$id'";
if ($con->query($delete) === TRUE){
    header("location: Carrito.php");
}
else{
    echo "No se pudo borrar";
}
?>