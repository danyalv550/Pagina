<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="AdminUsuarios.css">
    <title>Pizzeria</title>
</head>
<header class="title">
    <h1>Pizzeria Il Forno di Napoli</h1>
</header>
<nav>
    <ul id="barra">
        <li class="barraa"><a class="linkNav" href="IndexAdmin.php">Inicio</a>
        </li>
        <li class="barraa"><a class="linkNav" href="AdminMenu.php">Menu</a>
        </li>
        <li class="barraa"><a class="linkNav" href="AdminUbicacion.html">Ubicacion y contactos</a>
        </li>
        <li class="barraa"><a class="linkNav" href="AdminUsuarios.php">Usuarios</a>
        </li>
        <li class="barraa"><a class="linkNav" href="Home.php">Log out</a>
        </li>
    </ul>
</nav>
<body>
    <div class="searchbar">
        <div class="search">
            <form action="AdminUsuarios.php" method="Get">
            <?php 
            include 'Connection.php';
            @$search=$_GET['search'];
            ?>
            <input type="text" id="search" name="search" value="<?php echo $search?>">
            <button type="submit" name="Buscar" class="button">Buscar</button>
            <?php
            if(is_null($search)) {
                $sql = mysqli_query($con, "SELECT * FROM usuarios");
                $con->close();
            }
            else {
                $sql = mysqli_query($con, "SELECT * FROM usuarios WHERE name LIKE '%$search%' OR user LIKE '%$search%' OR pass LIKE '%$search%' OR phone LIKE '%$search%' OR email LIKE '%$search%'");
                $con->close();
            } ?>
            </form>
        </div>
    </div>
    <div class="general">
        <table>
        <thead>
        <tr>
            <th>Nombre</th><th>Usuario</th><th>Password</th><th>Email</th><th>Telefono</th><th><button onclick="window.location.href='AdminRegUser.php'">Agregar</button></th>
        </tr>
        </thead>
        <?php 
            include 'Connection.php';
            while($row = mysqli_fetch_array($sql))
            {
            ?> 
            <tr class="usuario">
                <td><?php echo $row['name'] ?></td>
                <td><?php echo $row['user'] ?></td>
                <td><?php echo $row['pass'] ?></td>
                <td><?php echo $row['email'] ?></td>
                <td><?php echo $row['phone'] ?></td>
                <td class="botones">
                    <button type="submit" name="Modificar" class="button" onclick="window.location.href='AdminModUser.php?id=<?php echo $row['id']?>';">Modificar</button>
                    <form method="POST" action="DelUser.php">
                        <button type="submit" name="Eliminar" class="button">Eliminar</button>
                        <input type="hidden" id="id" name="id" value="<?php echo $row['id'] ?>">
                    </form>
                </td>
            </tr>
            <?php
            }
        ?>
        </table>
    </div>
</body>
<footer>
    <div class="container">
        <div class="social-icons">
            <a href="https://www.instagram.com" target="_blank"> <img src="Imagenes/instagram.png" alt=""><i>Il Forno di Napoli</i></a>
            <a href="https://www.facebook.com" target="_blank"><img src="Imagenes/facebook.png" alt=""><i>Forno_di_Napoli</i></a>
        </div>
        <p>© 2023 Pizzería Il Forno di Napoli</p>
      </div>
</footer>
</html>