<?php
include 'Connection.php';

$permit = $_POST['permit'];
$name = $_POST['name'];
$user = $_POST['user'];
$pass = $_POST['pass'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$page = $_POST['page'];

$ConsultaUser = mysqli_query($con, "SELECT * FROM usuarios WHERE user = '$user'");
$ConsultaEmail = mysqli_query($con, "SELECT * FROM usuarios WHERE email = '$email'");
$ConsultaPhone = mysqli_query($con, "SELECT * FROM usuarios WHERE phone = '$phone'");

if($RepeatEmail = mysqli_fetch_assoc($ConsultaEmail)){
    switch ($permit) {
        case "admin":
            header("location: AdminRegUser.php?repeatemail=true");
            break;
        case "guest":
            header("location: RegistroPage.php?repeatemail=true");
            break;
        default:
            echo "Usuario no agregado";
      }
}
else if($RepeatUser = mysqli_fetch_assoc($ConsultaUser)){
    switch ($permit) {
        case "admin":
            header("location: AdminRegUser.php?repeatuser=true");
            break;
            break;
        case "guest":
            header("location: RegistroPage.php?repeatuser=true");
            break;
        default:
            echo "Usuario no agregado";
      }
}
else if($RepeatPhone = mysqli_fetch_assoc($ConsultaPhone)){
    switch ($permit) {
        case "admin":
            header("location: AdminRegUser.php?repeatphone=true");
            break;
        case "guest":
            header("location: RegistroPage.php?repeatphone=true");
            break;
        default:
            echo "Usuario no agregado";
      }
}
else{
    $Sql = mysqli_query($con,"INSERT INTO usuarios (id,name,user,pass,email,phone) values (0,'$name','$user','$pass','$email','$phone')");
    if($Sql){
        switch ($permit) {
            case "admin":
                header("location: AdminUsuarios.php");
                break;
            case "guest":
                header("location: LoginPage.php");
                break;
            default:
                echo "Usuario no agregado";
          }
    }
    else{
        echo "Usuario no agregado";
    }
}
?>