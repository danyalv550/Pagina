<?php
include 'Connection.php';

$id = $_POST['id'];
$delete = "DELETE FROM usuarios WHERE id='$id'";
if ($con->query($delete) === TRUE){
    header("location: AdminUsuarios.php");
}
else{
    echo "Usuario no agregado";
}
?>