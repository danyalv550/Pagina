<?php
session_start();
include 'Connection.php';

$idusuario = $_SESSION['user_id'];
$amount = $_POST['number'];
if($amount <= 0){
    header("location: Menu.php");
}
else{
    $idproducto = $_GET['idproducto'];
    $item = $_GET['item'];

    $SqlProduct = mysqli_query($con, "SELECT * FROM $item WHERE id = '$idproducto'");
    if($Producto = mysqli_fetch_assoc($SqlProduct)){
        $name = $Producto['name'];
        $image = $Producto['image'];
        $description = $Producto['description'];
        $price = $Producto['price'];
        $SqlRepeat = mysqli_query($con, "SELECT * FROM carrito WHERE idproducto = '$idproducto' AND idusuario = '$idusuario' AND name = '$name'");
        if($Repeat = mysqli_fetch_assoc($SqlRepeat)){
            $amount = $amount + $Repeat['amount'];
            $idrepeat = $Repeat['id'];
            $SqlUpdate = mysqli_query($con, "UPDATE carrito SET amount = '$amount' WHERE id = '$idrepeat'");
            header("location: Carrito.php");
        }
        else{
            $Sql = mysqli_query($con,"INSERT INTO carrito (id,idproducto,idusuario,name,image,description,price,amount) values (0,'$idproducto','$idusuario','$name','$image','$description','$price','$amount')");
            header("location: Carrito.php");
        }
    }
    else{
        echo "carrito no agregado";
    }
}

?>