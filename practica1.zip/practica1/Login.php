<?php
include 'Connection.php';

$user = $_POST['user'];
$pass = $_POST['pass'];

    $Sql = mysqli_query($con,"SELECT * FROM usuarios WHERE user = '$user' AND pass = '$pass' LIMIT 1" );
    $Admin = mysqli_query($con,"SELECT * FROM admin WHERE user = '$user' AND pass = '$pass' LIMIT 1" );
    if($usuario = mysqli_fetch_assoc($Admin)){
        $_SESSION['user_id'] = $usuario['id'];
        header("location: IndexAdmin.php");
    }
    else if($usuario = mysqli_fetch_assoc($Sql)){
        session_start();
        $_SESSION['user_id'] = $usuario['id'];
        $_SESSION['user_user'] = $usuario['user'];
        $_SESSION['user_email'] = $usuario['email'];
        header("location: Home.php");
    }
    else{
        header("location: LoginPage.php");
    }
?>