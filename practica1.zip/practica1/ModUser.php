<?php
include 'Connection.php';

$id = $_POST['id'];
$name = $_POST['name'];
$user = $_POST['user'];
$pass = $_POST['pass'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$permit = $_POST['permit'];

$ConsultaUser = mysqli_query($con, "SELECT * FROM usuarios WHERE id != '$id' AND user = '$user'");
$ConsultaEmail = mysqli_query($con, "SELECT * FROM usuarios WHERE id != '$id' AND email = '$email'");
$ConsultaPhone = mysqli_query($con, "SELECT * FROM usuarios WHERE id != '$id' AND phone = '$phone'");

if($RepeatEmail = mysqli_fetch_assoc($ConsultaEmail)){
    header("location: AdminRegUser.php?repeatemail=true&id=$id");
}
else if($RepeatUser= mysqli_fetch_assoc($ConsultaUser)){
    header("location: AdminRegUser.php?repeatuser=true&id=$id");
}
else if($RepeatPhone= mysqli_fetch_assoc($ConsultaPhone)){
    header("location: AdminRegUser.php?repeatphone=true&id=$id");
}
else{
    $update = "UPDATE usuarios SET name='$name', user='$user', pass='$pass', email='$email', phone='$phone' WHERE id='$id'";
    if ($con->query($update) === TRUE){
        header("location: AdminUsuarios.php");
    }
    else{
       echo "Usuario no agregado";
    }
}
?>