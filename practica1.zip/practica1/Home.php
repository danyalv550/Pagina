<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="HomeStyle.css">
    <title>Pizzeria</title>
</head>
<header class="title">
    <h1>Pizzeria Il Forno di Napoli</h1>
</header>
<nav>
    <ul id="barra">
        <?php
            if(empty($_SESSION['user_id'])){
                $link = "LoginPage.php";
                $text = "Log in";
            }
            else{
                $link = "LogOut.php";
                $username = $_SESSION['user_user'];
                $text = "Log out ($username)";
            }
        ?>
        <li class="barraa"><a class="linkNav" href="Home.php">Inicio</a>
        </li>
        <li class="barraa"><a class="linkNav" href="Menu.php">Menu</a>
        </li>
        <li class="barraa"><a class="linkNav" href="Ubicacion.php">Ubicacion y contactos</a>
        </li>
        <li class="barraa"><a class="linkNav" href=<?php echo $link ?>><?php echo $text?></a>
        </li>
        <?php if(empty($_SESSION['user_id'])){
            ?><li class="barraa"><a class="linkNav" href="RegistroPage.php">Registrarse</a>
            </li><?php
        }
        ?>
        <?php if(isset($_SESSION['user_id'])){
            ?><li class="barraa"><a class="linkNav" href="Carrito.php">Carrito</a><?php
        }
        ?>
        </li>
    </ul>
</nav>
<body>
<body>
    <h2 class="Slogan">
        Desde Italia hasta su barrio
    </h2>
    <section class="descripcion">
            <div class="imgCont">
                <img src="Imagenes\PizzaMarg.jpeg" alt="" class="image">
            </div>
            <div class="info">
                <p>
                    En esta humilde Pizzeria de barrio podra gozar de una rica comida autentica italiana, ya sea en el local con una reservacion, o en la comodidad de su casa con nuestro nuevo servicio a domicilio.
                </p>
            </div>
    </section>
    <section class="us">
    <div class="mision">
        <h2>Mision</h2>
        <p>
            Ofrecer a nuestros clientes una experiencia gastronómica auténtica e inolvidable, utilizando ingredientes frescos y de alta calidad, preparados con pasión por nuestro equipo de chefs italianos y brindando un servicio excepcional en un ambiente acogedor y amigable.
        </p>
    </div>
    <div class="vision">
        <h2>Vision</h2>
        <p>
            En nuestra pizzería, nos esforzamos por ser el lugar donde la auténtica cocina italiana se encuentra con el ambiente acogedor de una pizzería de barrio. Nuestra visión es ser reconocidos por nuestra excelencia culinaria y por el servicio excepcional que ofrecemos, manteniendo siempre la autenticidad de nuestros platos y la calidad de los ingredientes que utilizamos.
        </p>
    </div>
    </section>
</body>
<footer>
    <div class="container">
        <div class="social-icons">
            <a href="https://www.instagram.com" target="_blank"> <img src="Imagenes/instagram.png" alt=""><i>Il Forno di Napoli</i></a>
            <a href="https://www.facebook.com" target="_blank"><img src="Imagenes/facebook.png" alt=""><i>Forno_di_Napoli</i></a>
        </div>
        <p>© 2023 Pizzería Il Forno di Napoli</p>
      </div>
</footer>
</html>