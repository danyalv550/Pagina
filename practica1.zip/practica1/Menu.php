<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Menu.css">
    <title>Menu</title>
</head>
<header class="title">
    <h1>Pizzeria Il Forno di Napoli</h1>
</header>
<nav>
    <ul id="barra">
        <?php
            if(empty($_SESSION['user_id'])){
                $link = "LoginPage.php";
                $text = "Log in";
                $action = "LoginPage.php";
            }
            else{
                $link = "LogOut.php";
                $username = $_SESSION['user_user'];
                $text = "Log out ($username)";
                $action = "AddToCart.php";
            }
        ?>
        <li class="barraa"><a class="linkNav" href="Home.php">Inicio</a>
        </li>
        <li class="barraa"><a class="linkNav" href="Menu.php">Menu</a>
        </li>
        <li class="barraa"><a class="linkNav" href="Ubicacion.php">Ubicacion y contactos</a>
        </li>
        <li class="barraa"><a class="linkNav" href=<?php echo $link ?>><?php echo $text?></a>
        </li>
        <?php if(empty($_SESSION['user_id'])){
            ?><li class="barraa"><a class="linkNav" href="RegistroPage.php">Registrarse</a>
            </li><?php
        }
        ?>
        <?php if(isset($_SESSION['user_id'])){
            ?><li class="barraa"><a class="linkNav" href="Carrito.php">Carrito</a><?php
        }
        ?>
        </li>
    </ul>
</nav>
<body>
    <section class="menu">
        <h2>Pizzas</h2>
        <ul>
            <?php
                include 'Connection.php';
                foreach ($con->query('SELECT * from pizzas') as $pizzaRow){
                    ?>
                        <li class="item">
                            <div class="imageCont">
                                <img src="Imagenes/<?php echo $pizzaRow['image'];?>" alt="" class="image">
                            </div>
                            <div>
                                <h3><?php echo $pizzaRow['name'];?></h3>
                                <p><?php echo $pizzaRow['description'];?></p>
                                <div class="carrito">
                                    <form method="post" action="<?php echo $action ?>?idproducto=<?php echo $pizzaRow['id']?>&item=Pizzas">
                                    <button type="submit" name="kart" class="carrobtn"><input class="carrito" type="image" src="Imagenes/shopping-cart.png"></button>
                                    <input class="number" type="number" id="number" name="number" min="0">
                                    </form>
                                </div>
                                <span class="price">$<?php echo $pizzaRow['price'];?></span>
                            </div>
                        </li>
                    <?php
                }
            ?>
        </ul>
        <h2>Pastas</h2>
        <ul>
            <?php
                include 'Connection.php';
                foreach ($con->query('SELECT * from pastas') as $pastaRow){
                    ?>
                        <li class="item">
                            <div class="imageCont">
                                <img src="Imagenes/<?php echo $pastaRow['image']?>" alt="" class="image">
                            </div>
                            <div class="textCont">
                                <h3><?php echo $pastaRow['name']?></h3>
                                <p><?php echo $pastaRow['description']?></p>
                                <div class="carrito">
                                    <form method="post" action="<?php echo $action ?>?idproducto=<?php echo $pastaRow['id']?>&item=Pastas">
                                    <button type="submit" name="kart" class="carrobtn"><input class="carrito" type="image" src="Imagenes/shopping-cart.png"></button>
                                    <input class="number" type="number" id="number" name="number" min="0">
                                    </form>
                                </div>
                                <span class="price">$<?php echo $pastaRow['price']?></span>
                            </div>
                        </li>
                    <?php
                }
            ?>
        </ul>
        <h2>Postres</h2>
        <ul>
            <?php
                include 'Connection.php';
                foreach ($con->query('SELECT * from postres') as $postreRow){
                    ?>
                        <li class="item">
                            <div class="imageCont">
                                <img src="Imagenes/<?php echo $postreRow['image']?>" alt="" class="image">
                            </div>
                            <div class="textCont">
                                <h3><?php echo $postreRow['name']?></h3>
                                <p><?php echo $postreRow['description']?></p>
                                <div class="carrito">
                                    <form method="post" action="<?php echo $action ?>?idproducto=<?php echo $postreRow['id']?>&item=Postres">
                                    <button type="submit" name="kart" class="carrobtn"><input class="carrito" type="image" src="Imagenes/shopping-cart.png"></button>
                                    <input class="number" type="number" id="number" name="number" min="0">
                                    </form>
                                </div>
                                <span class="price">$<?php echo $postreRow['price']?></span>
                            </div>
                        </li>
                    <?php
                }
            ?>
        </ul>
    </section>
</body>
<footer>
    <div class="container">
        <div class="social-icons">
            <a href="https://www.instagram.com" target="_blank"> <img src="Imagenes/instagram.png" alt=""><i>Il Forno di Napoli</i></a>
            <a href="https://www.facebook.com" target="_blank"><img src="Imagenes/facebook.png" alt=""><i>Forno_di_Napoli</i></a>
        </div>
        <p>© 2023 Pizzería Il Forno di Napoli</p>
    </div>
</footer>
</html>