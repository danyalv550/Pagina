<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Ubicacion.css">
    <title>Ubicacion</title>
</head>
<header class="title">
    <h1>Pizzeria Il Forno di Napoli</h1>
</header>
<nav>
    <ul id="barra">
        <?php
            if(empty($_SESSION['user_id'])){
                $link = "LoginPage.php";
                $text = "Log in";
            }
            else{
                $link = "LogOut.php";
                $username = $_SESSION['user_user'];
                $text = "Log out ($username)";
            }
        ?>
        <li class="barraa"><a class="linkNav" href="Home.php">Inicio</a>
        </li>
        <li class="barraa"><a class="linkNav" href="Menu.php">Menu</a>
        </li>
        <li class="barraa"><a class="linkNav" href="Ubicacion.php">Ubicacion y contactos</a>
        </li>
        <li class="barraa"><a class="linkNav" href=<?php echo $link ?>><?php echo $text?></a>
        </li>
        <?php if(empty($_SESSION['user_id'])){
            ?><li class="barraa"><a class="linkNav" href="RegistroPage.php">Registrarse</a>
            </li><?php
        }
        ?>
        <?php if(isset($_SESSION['user_id'])){
            ?><li class="barraa"><a class="linkNav" href="Carrito.php">Carrito</a><?php
        }
        ?>
        </li>
    </ul>
</nav>
<body>
    <section class="genCont">
        <div class="Text">
            <h3>Ven a conocernos</h3>
            <p>Nos encontramos ubicados en la Colonia Providencia 5a seccion, en el 1885 de la Calle Nueva Escocia</p>
            <h3>Contactenos via celular</h3>
            <p>33 8888 8888</p>
        </div>
        <div class="locationCont">
            <img src="Imagenes/Ubicacion.png" alt="" class="location">
        </div>
    </section>
</body>
<footer>
    <div class="container">
        <div class="social-icons">
            <a href="https://www.instagram.com" target="_blank"> <img src="Imagenes/instagram.png" alt=""><i>Il Forno di Napoli</i></a>
            <a href="https://www.facebook.com" target="_blank"><img src="Imagenes/facebook.png" alt=""><i>Forno_di_Napoli</i></a>
        </div>
        <p>© 2023 Pizzería Il Forno di Napoli</p>
    </div>
</footer>
</html>