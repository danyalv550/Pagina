<?php

$server = "localhost";
$database = "Pizzeria_negocio";
$username =  "root";
$password = "123";

$con = mysqli_connect($server,$username,$password,$database);

if(!$con){
    echo "Conexion no exitosa";
}

?>