<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="AdminModProd.css">
    <title>Registro</title>
</head>
<header class="title">
    <h1>Pizzeria Il Forno di Napoli</h1>
</header>
<nav>
    <ul id="barra">
        <li class="barraa"><a class="linkNav" href="IndexAdmin.php">Inicio</a>
        </li>
        <li class="barraa"><a class="linkNav" href="AdminMenu.php">Menu</a>
        </li>
        <li class="barraa"><a class="linkNav" href="AdminUbicacion.html">Ubicacion y contactos</a>
        </li>
        <li class="barraa"><a class="linkNav" href="AdminUsuarios.php">Usuarios</a>
        </li>
        <li class="barraa"><a class="linkNav" href="Home.php">Log out</a>
        </li>
    </ul>
</nav>
<body>
    <section class="genCont">
        <form method="post" action="ModProd.php">
        <div class="form">
            <?php
                include 'Connection.php';
                $item = $_GET['item'];
                $id = $_GET['id'];
                $Sql = mysqli_query($con,"SELECT * FROM $item WHERE id = '$id'" );
                if($product = mysqli_fetch_assoc($Sql)){
                    ?>
                    <h2><?php echo $item; ?></h2>
                    <label>Nombre del producto</label>
                    <input type="text" id="name" name="name" value="<?php echo $product['name'] ?>">
                    <label>Imagen</label>
                    <input type="file" id="image" name="image" accept="image/jpg, image/jpeg, image/png, image/webp" value="Imagenes/<?php echo $product['image'] ?>">
                    <label>Descripcion</label>
                    <textarea name="description" id="description" rows="2" value="<?php echo $product['description'] ?>"></textarea>
                    <label>Precio</label>
                    <input type="text" id="price" name="price" value="<?php echo $product['price'] ?>">
                    <input type="hidden" id="id" name="id" value="<?php echo $id;?>">
                    <input type="hidden" id="item" name="item" value="<?php echo $item; ?>">
                    <?php
                }
            ?>
            <div class="botones">
                <button type="submit" name="Modificar" class="button">Modificar <?php echo $item; ?></button>
            </form>
                <form method="POST" action="DelProd.php">
                <?php
                    include 'Connection.php';
                    $item = $_GET['item'];
                    $id = $_GET['id'];
                    ?>
                    <button type="submit" name="Eliminar" class="button">Eliminar</button>
                    <input type="hidden" id="id" name="id" value="<?php echo $id;?>">
                    <input type="hidden" id="item" name="item" value="<?php echo $item; ?>">
                </form>
            </div>
        </div> 
    </section>
</body>
<footer>
    <div class="container">
        <div class="social-icons">
            <a href="https://www.instagram.com" target="_blank"> <img src="Imagenes/instagram.png" alt=""><i>Il Forno di Napoli</i></a>
            <a href="https://www.facebook.com" target="_blank"><img src="Imagenes/facebook.png" alt=""><i>Forno_di_Napoli</i></a>
        </div>
        <p>© 2023 Pizzería Il Forno di Napoli</p>
    </div>
</footer>
</html>