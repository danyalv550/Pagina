<?php
include 'Connection.php';

$item = $_POST['item'];
$id = $_POST['id'];
$delete = "DELETE FROM $item WHERE id='$id'";
if ($con->query($delete) === TRUE){
    header("location: AdminMenu.php");
}
else{
    echo "Usuario no agregado";
}
?>